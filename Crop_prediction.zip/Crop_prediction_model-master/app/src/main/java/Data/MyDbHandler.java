package Data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import Params.patrams;
import model.logindatabase;

public class MyDbHandler extends SQLiteOpenHelper {


    public MyDbHandler(Context context) {
        super(context, patrams.DB_NAME,null,patrams.DB_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
 String create="CREATE TABLE " +patrams.TABLE_NAME+"("+patrams.KEY_NAME+" TEXT ," +patrams.KEY_PASS +" TEXT "+")";
  db.execSQL(create);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public void addUsers(logindatabase ld){

        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues values= new ContentValues();
        values.put(patrams.KEY_NAME,ld.getName());
        values.put(patrams.KEY_PASS,ld.getPassword());
        db.insert(patrams.TABLE_NAME,null,values);
        Log.d("MyActivity", "done");
        db.close();

    }
    public List<logindatabase> getAllusers(){
        List<logindatabase> userlist= new ArrayList<>();
        SQLiteDatabase db=  this.getReadableDatabase();
        String select= "SELECT * FROM "+patrams.TABLE_NAME;
        Cursor cursor= db.rawQuery(select,null);
        if(cursor.moveToFirst()){
            do{
                logindatabase ld= new logindatabase();
                ld.setPassword(cursor.getString(0));
                ld.setPassword(cursor.getString(1));
                userlist.add(ld);
            }while(cursor.moveToNext());
        }
        return userlist;
    }
}
