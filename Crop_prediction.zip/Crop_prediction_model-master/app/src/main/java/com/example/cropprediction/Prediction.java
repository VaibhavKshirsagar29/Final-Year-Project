package com.example.cropprediction;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class Prediction extends Fragment {

    private PredictionViewModel mViewModel;
    private Spinner state, dis;
    View state_name;
    EditText s, d, n, p, k, r, ph, t, h, a, se, y;
    Button predict;
    String url = "https://crop122.herokuapp.com/predict";

   public static String st;
    public static Prediction newInstance() {
        return new Prediction();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(PredictionViewModel.class);

        // TODO: Use the ViewModel
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.prediction_fragment, container, false);
        Spinner sp=(Spinner)view.findViewById(R.id.state);
        ArrayAdapter<CharSequence> spa =ArrayAdapter.createFromResource(getContext(),R.array.states,
                android.R.layout.simple_spinner_item);
        spa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(spa);



        d = view.findViewById(R.id.District);
        a = view.findViewById(R.id.Area);
        se = view.findViewById(R.id.Season);
        y = view.findViewById(R.id.Year);
        t = view.findViewById(R.id.Temp);
        n = view.findViewById(R.id.N);
        p = view.findViewById(R.id.P);
        k = view.findViewById(R.id.N);
        ph = view.findViewById(R.id.Ph);
        h = view.findViewById(R.id.Humidity);
        r = view.findViewById(R.id.Rain);
        predict = view.findViewById(R.id.predict);
        st=sp.getSelectedItem().toString();
        predict.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                
                init();
            }
        });
        return view;
    }

    private void init() {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {


                    AlertDialog alert = null;
                    AlertDialog.Builder build = new AlertDialog.Builder(getActivity());
                    build.setTitle("Results");
                    build.setMessage(response);

                    build.setNegativeButton("OK", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub
                            Toast.makeText(getActivity(), "Hope it helps you", Toast.LENGTH_SHORT).show();
                           clearEverything();
                        }
                    });
                    build.create().show();

                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_LONG).show();
                        AlertDialog alert= null;
                        AlertDialog.Builder build= new AlertDialog.Builder(getActivity());
                        build.setTitle("Results");
                        build.setMessage("try again-"+error.getMessage());

                        build.setNegativeButton("OK", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // TODO Auto-generated method stub
                                Toast.makeText(getActivity(), "Try again", Toast.LENGTH_SHORT).show();
                                Intent intent =new Intent(getActivity(),Prediction.class);
                                startActivity(intent);
                                getActivity().finish();

                            }
                        });
                        build.create().show();


                    }


                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("rain", r.getText().toString());
                params.put("temp", t.getText().toString());
                params.put("State", st);
                params.put("District", d.getText().toString());
                params.put("Area", a.getText().toString());
                params.put("Crop_Year", y.getText().toString());
                params.put("Season", se.getText().toString());
                params.put("n", n.getText().toString());
                params.put("p", p.getText().toString());
                params.put("k", k.getText().toString());

                params.put("ph", ph.getText().toString());

                params.put("humidity", h.getText().toString());




                return params;
            }
        };
        RequestQueue queue= Volley.newRequestQueue(getActivity());
        queue.add(stringRequest);



    }

    private void clearEverything() {


    }


}