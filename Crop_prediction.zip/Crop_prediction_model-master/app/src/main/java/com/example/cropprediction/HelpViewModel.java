package com.example.cropprediction;

import androidx.lifecycle.ViewModel;

public class HelpViewModel extends ViewModel {
    // TODO: Implement the ViewModel



}
