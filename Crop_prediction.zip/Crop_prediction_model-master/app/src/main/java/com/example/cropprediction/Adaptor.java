package com.example.cropprediction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adaptor extends RecyclerView.Adapter<Adaptor.ViewHolder> {

    private List<mspAdaptor> userList;
    public Adaptor (List<mspAdaptor>userList){this.userList=userList;}

    @NonNull
    @Override
    public Adaptor.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.msplists,parent,false);
        return  new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adaptor.ViewHolder holder, int position) {

        String crop= userList.get(position).getTextview1();
        String price= userList.get(position).getTextview2();
        String sno= userList.get(position).getTextview3();

        holder.setData(crop,price,sno);

    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView textview1;
        private TextView textview2;
        private TextView textview3;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);


            textview1=itemView.findViewById(R.id.crop);
            textview2=itemView.findViewById(R.id.price);
            textview3=itemView.findViewById(R.id.sno);

        }

        public void setData(String crop, String price, String sno) {
            textview1.setText(crop);
            textview2.setText(price);
            textview3.setText(sno);
        }
    }
}
