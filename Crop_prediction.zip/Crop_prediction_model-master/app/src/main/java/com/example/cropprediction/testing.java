package com.example.cropprediction;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class testing extends AppCompatActivity {

    private PredictionViewModel mViewModel;
    private Spinner state, dis;
    View state_name;
    EditText s, d, n, p, k, r, ph, t, h, a, se, y;
    Button predict;
    String url = "https://crop122.herokuapp.com/predict";
    public static String st, di, cy, sea, crop;
    public static int sti, dii, cyi, seai, cropi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testing);
        Spinner sp = (Spinner) findViewById(R.id.state);
        ArrayAdapter<CharSequence> spa = ArrayAdapter.createFromResource(this, R.array.states,
                android.R.layout.simple_spinner_item);
        spa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(spa);
        d = findViewById(R.id.District);
        a = findViewById(R.id.Area);
        se = findViewById(R.id.Season);
        y = findViewById(R.id.Year);
        t = findViewById(R.id.Temp);
        n = findViewById(R.id.N);
        p = findViewById(R.id.P);
        k = findViewById(R.id.N);
        ph = findViewById(R.id.Ph);
        h = findViewById(R.id.Humidity);
        r = findViewById(R.id.Rain);
        predict = findViewById(R.id.predict);
        // sti=state.text.length()/28;
        dii = d.getText().toString().length() / 647;
        seai = se.getText().toString().length() / 6;
        sti = sp.getSelectedItem().toString().length() / 28;
        st = String.valueOf(sti);
        di = String.valueOf(dii);
        sea = String.valueOf(seai);
        predict.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                init();
            }
        });

    }

    private void init() {



            StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    try {


                        AlertDialog alert = null;
                        AlertDialog.Builder build = new AlertDialog.Builder(testing.this);
                        build.setTitle("Results");
                        build.setMessage(response);

                        build.setNegativeButton("OK", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // TODO Auto-generated method stub
                                Toast.makeText(testing.this, "Hope it helps you", Toast.LENGTH_SHORT).show();
                                Intent intent =new Intent(testing.this,Prediction.class);
                                startActivity(intent);
                                finish();
                            }
                        });
                        build.create().show();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                }
            },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(testing.this, error.getMessage(), Toast.LENGTH_LONG).show();
                            AlertDialog alert = null;
                            AlertDialog.Builder build = new AlertDialog.Builder(testing.this);
                            build.setTitle("Results");
                            build.setMessage("Madarchod-" + error.getMessage());

                            build.setNegativeButton("OK", new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    // TODO Auto-generated method stub
                                    Toast.makeText(testing.this, "Try again", Toast.LENGTH_SHORT).show();

                                }
                            });
                            build.create().show();


                        }


                    }) {
                @Override
                public Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("rain", r.getText().toString());
                    params.put("temp", t.getText().toString());
                    params.put("State", st);
                    params.put("District", di);
                    params.put("Area", a.getText().toString());
                    params.put("Crop_Year", y.getText().toString());
                    params.put("Season", sea);
                    params.put("n", n.getText().toString());
                    params.put("p", p.getText().toString());
                    params.put("k", k.getText().toString());

                    params.put("ph", ph.getText().toString());

                    params.put("humidity", h.getText().toString());






                    return params;
                }
            };
            RequestQueue queue = Volley.newRequestQueue(this);
            queue.add(stringRequest);


        }


    }
