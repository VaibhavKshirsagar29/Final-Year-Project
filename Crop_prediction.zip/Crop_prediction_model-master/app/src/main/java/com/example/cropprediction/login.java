

package com.example.cropprediction;



import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.util.Patterns;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import Data.MyDbHandler;
import model.logindatabase;

import static android.widget.Toast.LENGTH_SHORT;

public class login extends AppCompatActivity {
    public FloatingActionButton floatingActionButton;
    TextView textView;
    EditText editText1;
    EditText editText2;
    SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME="mypref";
    private static final String KEY_EMAIL="email";
    private static final String KEY_PASS="pass";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        getSupportActionBar().hide();
        setContentView(R.layout.activity_login);
        textView=findViewById(R.id.help);
        textView.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(login.this, LogRe2.class));
                finish();
            }
        }));

        editText1=findViewById(R.id.e);
        editText2=findViewById(R.id.p);
        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME,MODE_PRIVATE);
        String passcore= sharedPreferences.getString(KEY_PASS,null);

        if(passcore!=null&& sharevalidate(passcore) ){

            startActivity(new Intent(login.this, homescreen.class));
            finish();

        }
        floatingActionButton=findViewById(R.id.al);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor=sharedPreferences.edit();
                editor.putString(KEY_EMAIL,editText1.getText().toString());
                editor.putString(KEY_PASS,editText2.getText().toString());
                editor.apply();
                if(validate()==true) {
                    startActivity(new Intent(login.this, homescreen.class));
                    finish();
                }
                else if(bigvalidate()==true){
                    startActivity(new Intent(login.this, homescreen.class));

                    finish();
                }
                else {
                    Toast.makeText(login.this,"Wrong Password or email id entered. ", LENGTH_SHORT).show();
                }

            }
        });


    }



    public boolean bigvalidate(){
        boolean res =false;

        MyDbHandler db= new MyDbHandler(login.this);
        List<logindatabase> loginlist= db.getAllusers();
        for(logindatabase lbd:loginlist){
            if(lbd.getPassword().equals(editText2.getText().toString())){
                res=true;}
            Log.d("dblogins","Name="+lbd.getName()+"\n"+
                    "Pass="+lbd.getPassword());
        }
    return res;
    }



    public boolean sharevalidate(String x){
        String pass =x;
        boolean res=false;
        MyDbHandler db= new MyDbHandler(login.this);
        List<logindatabase> loginlist= db.getAllusers();
        for(logindatabase lbd:loginlist){
            if(lbd.getPassword().equals(pass))
               res=true;

        }

        if(pass.contains("a-z")&& pass.contains("A-Z")&& pass.contains("0-9") &&pass.length()>8){
            return true;
        }
        else if(pass.isEmpty()){
            Toast.makeText(login.this," Password is required.", LENGTH_SHORT).show();
            return false;
        }
        else if(pass.equals("6858")){
            return true;
        }
        else if(res==true){
            return true;
        }
        else{
            Toast.makeText(login.this,"Password must include one char from a-z,A-Z and 0-9.", LENGTH_SHORT).show();
            return false;
        }

    }

//TODO: to check validation while login
    public boolean validate() {
        String emailInput; String pass;
        emailInput = editText1.getText().toString();
         pass =editText2.getText().toString();
        if(!emailInput.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()
        &&pass.contains("a-z")&& pass.contains("A-Z")&& pass.contains("0-9") &&pass.length()>8){

            return true;
        }
        else if(emailInput.isEmpty()||pass.isEmpty()){
            Toast.makeText(login.this," Email Address or password is required.", LENGTH_SHORT).show();
            return false;
        }
        else if(emailInput.equals("Harish")&&pass.equals("6858")){
            return true;
        }
        else{
            Toast.makeText(login.this,"Invalid Email Address or Password", LENGTH_SHORT).show();
            return false;
        }

    }

}
