package com.example.cropprediction;

import androidx.core.view.GravityCompat;
import androidx.lifecycle.ViewModelProviders;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class Help extends Fragment {

    private HelpViewModel mViewModel;
    private ImageView doCall;
    private ImageView contactGmail;

    private String[] PERMISSIONS = new String[]{Manifest.permission.CALL_PHONE, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION};

    private static final int REQUEST_Call = 1;


    public static Help newInstance() {
        return new Help();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {


        View view=inflater.inflate(R.layout.help_fragment, container, false);


        //TODO: initialise do call
        //TODO: set contact call/email by on clicked
        doCall=view.findViewById(R.id.imageView5);
        contactGmail=view.findViewById(R.id.imageView6);

        //TODO: set on clicked listener on doCall
        doCall.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {

//        Toast.makeText(Help.this.getClass(),"Dial panel is open",Toast.LENGTH_SHORT).show();
//        binding.drawer.closeDrawer(GravityCompat.START);

        Intent intentDial = new Intent(Intent.ACTION_DIAL);
        intentDial.setData(Uri.parse("tel:9643589226"));
        startActivity(intentDial);

    }
    //TODO: call the doCall method
    private void doCall() {

        Intent intentCall = new Intent(Intent.ACTION_CALL, Uri.parse("tel:9643589226"));
        startActivity(intentCall);
    }
});
        //TODO: set on click listener on contactGmail
contactGmail.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {

        Intent email = new Intent(Intent.ACTION_SEND);
        email.putExtra(Intent.EXTRA_EMAIL, new String());
        email.putExtra(Intent.EXTRA_TEXT, "This is my text to send.");
        startActivity(Intent.createChooser(email, "Choose an Email client :"));
//need this to prompts email client only
        email.setType("message/rfc822");
        startActivity(Intent.createChooser(email, "Choose an Email client :"));


    }
});

        return view;


    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(HelpViewModel.class);
        // TODO: Use the ViewModel

    }

}
