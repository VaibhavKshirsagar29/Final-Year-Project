package com.example.cropprediction;

import androidx.lifecycle.ViewModel;

public class MspViewModel extends ViewModel {

}
