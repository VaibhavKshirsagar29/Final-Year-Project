package com.example.cropprediction;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.WindowManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.regex.Pattern;

import Data.MyDbHandler;
import model.logindatabase;

import static android.widget.Toast.*;

public class LogRe2 extends AppCompatActivity {
    TextView textview;
    TextView textview1;
    EditText editText;
    EditText editText1;
    EditText editText2;

    public FloatingActionButton floatingActionButton;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        setContentView(R.layout.activity_log_re2);
        textview=findViewById(R.id.t);
        textview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LogRe2.this,login.class));
                finish();
            }
        });
        floatingActionButton=findViewById(R.id.al);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyDbHandler db= new MyDbHandler(LogRe2.this);
                logindatabase ld= new logindatabase();
                if(validate()==true && validate1()==true && validate2()==true)

                    ld.setName(editText1.getText().toString());
                ld.setPassword(editText2.getText().toString());
                db.addUsers(ld);
                startActivity(new Intent(LogRe2.this,login.class));

            }

        });
        textview=findViewById(R.id.u);
        editText=findViewById(R.id.n);
        editText1=findViewById(R.id.e);
        editText2=findViewById(R.id.p);
        MyDbHandler db= new MyDbHandler(LogRe2.this);
        logindatabase ld= new logindatabase();



    }

public boolean validate2(){
    String name =editText.getText().toString();
    if(name.contains("a-z")||name.contains("A-Z")){
        return true;
    }
    else if(name.isEmpty()){
        Toast.makeText(LogRe2.this," Username is required.", LENGTH_SHORT).show();
        return false;
    }
    else{
        Toast.makeText(LogRe2.this,"Please enter a valid username", LENGTH_SHORT).show();
        return false;


}}
public boolean validate1(){
    String pass =editText2.getText().toString();
    if(pass.contains("a-z")&& pass.contains("A-Z")&& pass.contains("0-9") &&pass.length()>8){
        return true;
    }
    else if(pass.isEmpty()){
        Toast.makeText(LogRe2.this," Password is required.", LENGTH_SHORT).show();
        return false;
    }
    else{
        Toast.makeText(LogRe2.this,"Password must include one char from a-z,A-Z and 0-9.", LENGTH_SHORT).show();
        return false;
    }

}

    public boolean validate() {
        String emailInput;
        emailInput = editText1.getText().toString();
        if(!emailInput.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()){

            return true;
        }
        else if(emailInput.isEmpty()){
            Toast.makeText(LogRe2.this," Email Address is required.", LENGTH_SHORT).show();
            return false;
        }
        else{
           Toast.makeText(LogRe2.this,"Invalid Email Address", LENGTH_SHORT).show();
            return false;
        }

    }
}