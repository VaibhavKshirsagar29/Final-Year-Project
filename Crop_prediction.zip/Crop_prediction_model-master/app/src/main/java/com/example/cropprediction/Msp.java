package com.example.cropprediction;

import androidx.appcompat.widget.SearchView;
import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import com.opencsv.CSVReader;
import java.io.IOException;
import java.io.FileReader;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;


public class Msp extends Fragment {
    public  static String []Data;
    public  static String []Data2;
     InputStream inputStream;
    private MspViewModel mViewModel;
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    List<mspAdaptor> userList;
    Adaptor adaptor;
    static int i=0;

    public static Prediction newInstance() {
        return new Prediction();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view= inflater.inflate(R.layout.msp_fragment, container, false);
        recyclerView=view.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        initData();
        recyclerView.setAdapter(new Adaptor(initData()));
        return view;


    }

    private List<mspAdaptor> initData() {

        //TODO: here we are fecthing the msp list which is saved in our raw file
        userList = new ArrayList<>();
        InputStream is = getResources().openRawResource(R.raw.msp);

        //TODO: Reads text from character-input stream, buffering characters for efficient reading
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(is, Charset.forName("UTF-8"))
        );

        // Initialization
        String line = "";

        // Initialization
        try {
            // Step over headers
            reader.readLine();

            // If buffer is not empty
            while ((line = reader.readLine()) != null) {
                Log.d("MyActivity","Line: " + line);
                i++;
                // use comma as separator columns of CSV
                String[] tokens = line.split(",");
                // Read the data

                userList.add(new mspAdaptor(tokens[1],tokens[2],tokens[0]));
                // Adding object to a class


                // Log the object

            }

        } catch (IOException e) {
            // Logs error with priority level
            Log.wtf("MyActivity", "Error reading data file on line" + line, e);

            // Prints throwable details
            e.printStackTrace();
        }

        return userList;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(MspViewModel.class);
        // TODO: Use the ViewModel
    }
    //-------------------------------------------------
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.search_filter, menu);
        MenuItem searchItem = menu.findItem(R.id.Search);
        SearchView searchView = (SearchView) searchItem.getActionView();
        searchView.setOnQueryTextListener((SearchView.OnQueryTextListener) this);
        searchView.setQueryHint("Search");

        super.onCreateOptionsMenu(menu, inflater);

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

}
