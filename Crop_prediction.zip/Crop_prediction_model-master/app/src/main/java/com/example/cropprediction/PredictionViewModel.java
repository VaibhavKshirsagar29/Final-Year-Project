package com.example.cropprediction;

import androidx.lifecycle.ViewModel;

public class PredictionViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
