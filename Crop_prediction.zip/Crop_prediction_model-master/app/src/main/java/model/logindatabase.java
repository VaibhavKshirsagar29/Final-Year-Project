package model;

public class logindatabase {
    public String name;
            public  String password;

            public logindatabase(String password,String name){
                this.password=password;
                this.name=name;
            }

            public logindatabase(){

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
